import { environment as common } from './environment';

// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyAS5hBhqaZCXHfTuq954zoEvN_Dm9n9JGU",
    authDomain: "buscocredito-c380b.firebaseapp.com",
    databaseURL: "https://buscocredito-c380b.firebaseio.com",
    projectId: "buscocredito-c380b",
    storageBucket: "buscocredito-c380b.appspot.com",
    messagingSenderId: "731179638072",
    appId: "1:731179638072:web:2268037f8dd97a238b35cd",
    measurementId: "G-F8KXMW6WN2"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
