import { environment as common } from './environment';

export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyAS5hBhqaZCXHfTuq954zoEvN_Dm9n9JGU",
    authDomain: "buscocredito-c380b.firebaseapp.com",
    databaseURL: "https://buscocredito-c380b.firebaseio.com",
    projectId: "buscocredito-c380b",
    storageBucket: "buscocredito-c380b.appspot.com",
    messagingSenderId: "731179638072",
    appId: "1:731179638072:web:2268037f8dd97a238b35cd",
    measurementId: "G-F8KXMW6WN2"
  }
};
