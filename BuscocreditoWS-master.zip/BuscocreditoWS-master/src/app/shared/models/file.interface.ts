export interface FileI{

    name: String;
    imageFile: File;
    size: String;
    type: String;
}