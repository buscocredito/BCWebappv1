
export interface PostI {

    titlePost?: string;
    contentPost?: string;
    imagePost?: any;
    id?: any;
    tagsPost?: string;
    fileRef?: string;
    nameUser?: string;
    moneyPost?: string;
    monthPost?: string;
    userUId?: string;
    email?: string;

    // New 
    nombre?: string,
    tipoCredito?: string,
    propositoCredito?: string,
    montoSolicitado?: string,
    plazo?: string,
    periocidadCredito?: string,

}
